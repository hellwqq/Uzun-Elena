deep sample
